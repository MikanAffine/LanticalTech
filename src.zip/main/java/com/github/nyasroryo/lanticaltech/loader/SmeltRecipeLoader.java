package com.github.nyasroryo.lanticaltech.loader;

public class SmeltRecipeLoader {
  public static final void LoadSmeltRecipe(){

  }
}
