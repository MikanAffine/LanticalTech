package com.github.nyasroryo.lanticaltech.packedconsts;

public abstract class OtherConsts {

  public static final String[] Colors = {"white", "orange", "magenta", "lightblue", "yellow", "lime", "pink", "gray", "lightgray", "cyan", "purple", "blue", "brown", "green", "red", "black"};



}
