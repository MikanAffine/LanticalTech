package com.github.nyasroryo.lanticaltech.packedconsts;

import com.github.nyasroryo.lanticaltech.common.item.*;
import net.minecraft.item.Item;

public abstract class ItemList {

  public static final Item[] ItemObject = {
      Ingot.THIS_ITEM,
      Plate.THIS_ITEM,
      Dust.THIS_ITEM,
      Fuel.THIS_ITEM,
      Gem.THIS_ITEM

  };
}